from imutils.video import VideoStream

from imutils import face_utils

import numpy as np

import argparse

import imutils

import time

import dlib

import cv2



def euclidean_dist(ptA, ptB):

    # compute and return the euclidean distance between the two

    # points

    return np.linalg.norm(ptA - ptB)





def eye_aspect_ratio(eye):

    # compute the euclidean distances between the two sets of

    # vertical eye landmarks (x, y)-coordinates

    A = euclidean_dist(eye[1], eye[5])

    B = euclidean_dist(eye[2], eye[4])



    # compute the euclidean distance between the horizontal

    # eye landmark (x, y)-coordinates

    C = euclidean_dist(eye[0], eye[3])



    # compute the eye aspect ratio

    ear = (A + B) / (2.0 * C)



    # return the eye aspect ratio

    return ear



EYE_AR_THRESH = 0.25

EYE_AR_CONSEC_FRAMES = 16



# load OpenCV's Haar cascade for face detection (which is faster than

# dlib's built-in HOG detector, but less accurate), then create the

# facial landmark predictor

print("[INFO] loading info")

detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")



# grab the indexes of the facial landmarks for the left and

# right eye, respectively

(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]

(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]



# start the video stream thread

print("[INFO] starting video")

vs = VideoStream(src=0).start()

# vs = VideoStream(usePiCamera=True).start()

time.sleep(1.0)



flag = 0

start = 0

end = 0

sendFlag = 0



# loop over frames from the video stream

while True:

    frame = vs.read()

    #frame = imutils.resize(frame, width=450)

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)



    #rects = detector.detectMultiScale(gray, scaleFactor=1.1,

    #                                  minNeighbors=5, minSize=(30, 30),

    #                                  flags=cv2.CASCADE_SCALE_IMAGE)

    rects = detector.detectMultiScale(gray, 1.5)



    # loop over the face detections

    for (x, y, w, h) in rects:

        # construct a dlib rectangle object from the Haar cascade

        # bounding box

        rect = dlib.rectangle(int(x), int(y), int(x + w),

                              int(y + h))



        # determine the facial landmarks for the face region, then

        # convert the facial landmark (x, y)-coordinates to a NumPy

        # array

        shape = predictor(gray, rect)

        shape = face_utils.shape_to_np(shape)



        # extract the left and right eye coordinates, then use the

        # coordinates to compute the eye aspect ratio for both eyes

        leftEye = shape[lStart:lEnd]

        rightEye = shape[rStart:rEnd]

        leftEAR = eye_aspect_ratio(leftEye)

        rightEAR = eye_aspect_ratio(rightEye)



        # average the eye aspect ratio together for both eyes

        ear = (leftEAR + rightEAR) / 2.0



        # compute the convex hull for the left and right eye, then

        # visualize each of the eyes

        leftEyeHull = cv2.convexHull(leftEye)

        rightEyeHull = cv2.convexHull(rightEye)

        cv2.drawContours(frame, [leftEyeHull], -1, (255, 255, 255), 1)

        cv2.drawContours(frame, [rightEyeHull], -1, (255, 255, 255), 1)



        # check to see if the eye aspect ratio is below the blink

        # threshold, and if so, increment the blink frame counter
	print(ear)
        if ear < EYE_AR_THRESH:

            if (flag == 0):

                start = time.time()

            flag = 1

            if (flag == 1):

                end = time.time()

            #print(end - start)



            if (end - start > 1.0 and sendFlag == 0):

                f = open("detect", "w")

                f.write("1")

                f.close()

                sendFlag = 1

	    if(end - start > 1.0):
                # draw an text on the frame

                cv2.putText(frame, "DROWSINESS ALERT!", (450/2, 450/2),

                            cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)



        # otherwise, the eye aspect ratio is not below the blink

        else:

            flag = 0

            sendFlag = 0



        # draw the computed eye aspect ratio on the frame to help

        # with debugging and setting the correct eye aspect ratio

        # thresholds and frame counters

        #cv2.putText(frame, "Value: {:.3f}".format(ear), (300, 30),
        #           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)



    # show the frame

    cv2.imshow("Frame", frame)

    key = cv2.waitKey(1) & 0xFF



    # if the `q` key was pressed, break from the loop

    if key == ord("q"):

        break

    if key == ord("s"):
	print("hhh")

# do a bit of cleanup

cv2.destroyAllWindows()

vs.stop()
